package org.nfctools.llcp.parameter;

public class ReceiveWindowSize {

	private int size;

	public ReceiveWindowSize(int size) {
		this.size = size;
	}

	public int getSize() {
		return size;
	}

}
