package org.nfctools.api;


public interface ReaderWriter {
}
