#include "main.h"

int main(int argc, char **argv)
{
    return cardpeek_main(argc,argv);
}
