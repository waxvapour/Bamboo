-- This file is free for the user to modify
-- It is executed after config.lua


-- The next line is needed for card commands.
require("scripts.lib.apdu")
dofile("scripts/lib/compatibility-with-0.7.lua")
