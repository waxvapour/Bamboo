#ifndef _MAIN_H_
#define _MAIN_H_

int cardpeek_main(int argc, char **argv);

#endif
