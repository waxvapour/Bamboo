

#define CARDPEEK_PUBLIC_KEY \
    "-----BEGIN PUBLIC KEY-----\n" \
    "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAxY/1mOsNZnWpdDxdfOWy\n" \
    "Db/R0uM6MXtNcAIlGnF22Ial5ecbTejBcI+L6ctUK3hxa9vswv0b2rqbcEh+dkAl\n" \
    "EPDrw3dUm2Oyn7ysuToa5RXcSYw1yX1BVLDI82+1XPEV5yAQBb8rQ42877e50U0B\n" \
    "nshI5FXRSY4/qtrd7/twpr5DeSEo9K/wsyfbG/z3kieGVPdJViffF4JSZi1qVZE/\n" \
    "/GFm4Bf/APtMkELrhLUnY69TQw1vDROTVJOQU/hEsEmQIAO7RH/NbLQaMqpBklGE\n" \
    "jAfJQO54IHU2DuCHjSByz17ujovszwmsC8xpI00X9pH9OO5CnLUP4V0NNSeEdhNH\n" \
    "RQIDAQAB\n" \
    "-----END PUBLIC KEY-----\n" \
    ""


