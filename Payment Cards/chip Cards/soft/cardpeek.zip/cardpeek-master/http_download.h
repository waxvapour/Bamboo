#ifndef _HTTP_DOWNLOAD_H_
#define _HTTP_DOWNLOAD_H_

int http_download(const char *src_url, const char *dst_filename);

#endif
