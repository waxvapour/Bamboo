# ddos-script
All  things to do after installing Kali Linux and Add more awesome hacking tools to your Kali Linux system


Review ddos script: https://www.youtube.com/watch?v=RZGmrzPdm0w

Contact: https://www.youtube.com/c/penetrationtestingwithkalilinux
